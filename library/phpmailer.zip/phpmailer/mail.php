<?php
session_start();
require './library/PHPMailer/src/Exception.php';
require './library/PHPMailer/src/PHPMailer.php';
require './library/PHPMailer/src/SMTP.php';

//Import PHPMailer classes into the global namespace
//These must be at the top of your script, not inside a function
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

// Access the global variable
$smtp_config = $GLOBALS['smtp_config'];

//Create an instance; passing `true` enables exceptions
$mail = new PHPMailer(true);
try {
    //Server settings
    $mail->SMTPDebug  = SMTP::DEBUG_SERVER;                     //Enable verbose debug output
    $mail->SMTPSecure = $smtp_config['secure'];                 //Enable verbose debug output
    $mail->isSMTP();                                            //Send using SMTP
    $mail->Host       = $smtp_config['host'];                   //Set the SMTP server to send through
    $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
    $mail->Username   = $smtp_config['username'];               //SMTP username
    $mail->Password   = $smtp_config['password'];               //SMTP password
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
    $mail->Port       = $smtp_config['port'];                   //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`

    //Recipients
    $mail->setFrom("bib-notice@erfoundation.org", "bib-notice");

    //Content
    $mail->isHTML(true);                                  //Set email format to HTML
    $mail->Subject = "New record(s) entered in the ERF bibliography";
    // sendMail($row['email'], $row['name'], $msg);
    $mail->AddAddress('ilham05saputra@gmail.com', 'ilham');
    $mail->Body    = 'testing';
    $mail->Send();

    // Reset pengaturan email untuk penerima berikutnya
    $mail->clearAddresses();
    sleep(1); // Tambahkan jeda untuk menghindari pembatasan pengiriman email
} catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
}
