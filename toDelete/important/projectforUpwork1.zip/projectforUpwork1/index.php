<?php
	if (session_status() == PHP_SESSION_NONE) {
		session_start();
	}
  
?>
<html lang="en">
<head>
<title>Home</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<!-- Latest compiled JavaScript -->
<link rel="stylesheet" type="text/css" href="./script1.css"/>
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
<style>
body {font-family: "Lato", sans-serif}
.mySlides {display: none}
</style>
</head>
<body style="background-color:#000000; height:100%;">

<!-- Navbar -->
<div class="w3-top" style="height: 46;">
  <div class="w3-bar w3-black w3-card" style="height: 46;">
  <a href="login.php" class ="w3-bar-item " style="width:50px;height:20px;"><img src="websiteimages/tstologo.png" alt="Home" style="width:30px;height:30px;"></a>
    <?php
      if (isset($_SESSION['status']) && $_SESSION['status'] == "loggedin"){
        ?>
        
        <a href="./destroy.php" class="w3-bar-item w3-button w3-padding-large w3-hide-small">Log out</a>
    <?php
      }else{
        ?>
        <a href="login.php" class="w3-bar-item w3-button w3-padding-large">Login</a>
        <a href="signUp.php" class="w3-bar-item w3-button w3-padding-large w3-hide-small">Sign Up</a>
        <?php
      }
    ?>
    
    <a href="https://www.paypal.me/simpsonstapper/5" class="w3-bar-item w3-button w3-padding-large w3-hide-small">Donate</a>
    <a href="https://twitter.com/tstohome" style="height: 46;" class="w3-padding-large w3-hover-red w3-hide-small w3-right"><i class="fab fa-twitter w3-hover-opacity"></i></a>
    <a href="https://www.facebook.com/tstohome" style="height: 46;" class="w3-padding-large w3-hover-red w3-hide-small w3-right"><i class="fab fa-facebook w3-hover-opacity"></i></a>
    <a href="https://www.youtube.com/channel/UC3a82zPBXGJ2tHBv0Q13pGw/" style="height: 46;" class="w3-padding-large w3-hover-red w3-hide-small w3-right"><i class="fab fa-youtube w3-hover-opacity"></i></a>
    <a href="https://www.paypal.me/simpsonstapper/5" style="height: 46;" class="w3-padding-large w3-hover-red w3-hide-small w3-right"><i class="fab fa-paypal w3-hover-opacity"></i></a>
    <a href="https://discord.gg/9sYXqGfyAC" style="height: 46;" class="w3-padding-large w3-hover-red w3-hide-small w3-right"><i class="fab fa-discord w3-hover-opacity"></i></a>
  </div>
</div>

<!-- Page content -->
<div class="w3-content" style="max-width:2000px;" style="position: relative;">

  <!-- Automatic Slideshow Images -->
  <div class="mySlides w3-display-container w3-center">
    <img src="websiteimages/banner1.png" style="width:100%;top:0;object-fit: cover;
  height: 550px;">
  </div>
  <div class="mySlides w3-display-container w3-center">
    <img src="websiteimages/banner5.png" style="width:100%;top:0;object-fit: cover;
  height: 550px;">
  </div>
  <div class="mySlides w3-display-container w3-center">
    <img src="websiteimages/banner4.png" style="width:100%;top:0;object-fit: cover;
  height: 550px;">
  </div>
  <div class="mySlides w3-display-container w3-center">
    <img src="websiteimages/banner3.png" style="width:100%;top:0;object-fit: cover;
  height: 550px;">
  </div>
  <div class="mySlides w3-display-container w3-center">
    <img src="websiteimages/banner2.png" style="width:100%;top:0;object-fit: cover;
  height: 550px;">
  </div>
  <div class="mySlides w3-display-container w3-center">
    <img src="websiteimages/banner.png" style="width:100%;top:0;object-fit: cover;
  height: 550px;">
  </div>
    <?php
        if (isset($_SESSION['status']) && $_SESSION['status'] == "loggedin"){
          include "currentuser.php"
      ?>
    <div class="w3-container w3-text-white w3-padding-32 w3-hide-small" style="border-radius: 25px;
    position:absolute;bottom:30%;left:5%;
    background: #000000;
    padding: 20px;
    width: 800px;
    height: max-content;">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-1 justify-content-center">
          <img src="websiteimages/logobar.png" style="background: #000; height: 60px; width: auto;">
          </div>
          <div class="col-3 justify-content-center">
          <h3 style="">Welcome <?php echo($_SESSION["name"]) ?></h3>
          </div>
          <div class="col-2 justify-content-center">
            <div class="row">
            <p style="color:orange">IP Address</p>
            </div>
            <div class="row">
            <p><?php echo($_SESSION["ip"]) ?></p>
            </div>
          </div>
          <div class="col-3 justify-content-center">
            <div class="row">
            <p style="color:orange">Subscription Starts</p>
            </div>
            <div class="row">
            <p style=""><?php echo($_SESSION["registrationDate"]) ?></p>
            </div>
          </div>
          <div class="col-3 justify-content-center">
            <div class="row">
            <p style="color:orange">Subscription Ends</p>
            </div>
            <div class="row">
            <p style=""><?php echo($_SESSION["subscriptionDate"]) ?></p>
            </div>
          </div>
        </div>
      </div>
      <?php
        }
        ?>
    </div>
  </div>
<!-- End Page Content -->
</div>

<?php
      if (isset($_SESSION['status']) && $_SESSION['status'] == "loggedin" && strtotime(date('Y-m-d', strtotime($_SESSION['subscriptionDate'])))>=strtotime(date('Y-m-d'))){
        ?>
<div class="w3-black" id="tour">
      </br></br>
<div class="container" style="background-color: #000000;width:100%;">
    <div class="row">
      <div class="col-sm d-flex justify-content-center">
        <a href="http://simpsonstapper.com/apk/32bit.apk"><img src="websiteimages/32bit.png" style="width:120px;height:120px;"></a>
      </div>
      <div class="col-sm d-flex justify-content-center">
      <a href="http://simpsonstapper.com/apk/64bit.apk"><img src="websiteimages/64bit.png" style="width:120px;height:120px;"></a>
      </div>
      <div class="col-sm d-flex justify-content-center">
      <a href="http://simpsonstapper.com/apk/normalgame.apk"><img src="websiteimages/normalgame.png" style="width:120px;height:120px;"></a>
      </div>
      <div class="col-sm d-flex justify-content-center">
      <a href="http://simpsonstapper.com/apk/rootfiles.zip"><img src="websiteimages/rootfiles.png" style="width:120px;height:120px;"></a>
      </div>
      <div class="col-sm d-flex justify-content-center">
      <a href="http://simpsonstapper.com/apk/bluestacksinstaller.exe"><img src="websiteimages/bluestacks.png" style="width:120px;height:120px;"></a>
      </div>
    </div>
    </br></br>
  </div>
</div>
  <?php }else{
  ?>
  <div class="w3-black" id="tour">
  </br>
  <div class="container">
    <div class="row d-flex justify-content-center">
    <img src="websiteimages/attention.png"/>
    </br></br>
    </div>
  </div>
  </div>
  <?php
} ?>

</div>

<script>
// Automatic Slideshow - change image every 4 seconds
var myIndex = 0;
carousel();

function carousel() {
  var i;
  var x = document.getElementsByClassName("mySlides");
  for (i = 0; i < x.length; i++) {
    x[i].style.display = "none";  
  }
  myIndex++;
  if (myIndex > x.length) {myIndex = 1}    
  x[myIndex-1].style.display = "block";  
  setTimeout(carousel, 4000);    
}

// Used to toggle the menu on small screens when clicking on the menu button

</script>

</body>
</html>