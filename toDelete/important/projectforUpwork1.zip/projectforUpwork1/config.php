<?php
	$hostName = "simpsonstapper.com";
	$username = "simpsper_test";
	$password = "testingpassword12@";
	$databaseName = "simpsper_tstoDB";
	$connection = new mysqli($hostName,$username,$password,$databaseName);

if ($connection -> connect_errno) {
  echo "Failed to connect to MySQL: " . $connection -> connect_error;
  exit();
}
?>